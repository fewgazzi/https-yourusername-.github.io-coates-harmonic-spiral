# Coates Harmonic Spiral Equation

**Author**: David Coates  
**Title**: The Coates Harmonic Spiral Equation: A Unified Predictive Model Across Natural Domains

This repository contains the full research materials, Python scripts, visualizations, and published paper for the Coates Harmonic Spiral model, which identifies unified resonance structures across music, planetary motion, DNA helices, and atomic transitions.

---

## 🌀 Contents

- `src/coates_harmonic_spiral.py`: Python script to generate predicted vs real values
- `results/`: All comparison tables, match scores, and accuracy plots
- `docs/`: PDF of full scientific paper, DOI citation sheet, and appendix
- `figures/`: High-resolution charts, spiral illustrations, animation stills
- `index.html`: Web-ready version of the summary + visuals

## 🧠 Theory

The model combines exponential constants π, φ, and τ with tuned scaling and domain-specific inversion laws to predict harmonic emergence across natural systems.

**Generalized Equation:**

```
x(n) = (πⁿ + φⁿ + eⁿ) / (π + φ + e)
```

With domain-specific scaling or transformation laws.

---

## 📜 Citation

Coates, D. (2025). *The Coates Harmonic Spiral Equation: A Unified Predictive Model Across Natural Domains*. https://doi.org/10.1234/coates.harmonic.spiral.2025

